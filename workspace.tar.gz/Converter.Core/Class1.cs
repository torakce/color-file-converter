﻿namespace Converter.Core;

public class Class1
{

}
